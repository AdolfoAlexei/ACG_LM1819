<?php


?>

<div id="contenido">

<h2>BUSCADOR DE PAISES</h2>

<p>Insertar el nombre del pais a buscar</p>
<form action="Resultadopais.php" method="post">
	<input type="text" name="cpalabra" /> <input type="submit" value="Buscar" />
</form>

</div>

<?php